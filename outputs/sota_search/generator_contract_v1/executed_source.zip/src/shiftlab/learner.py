"""Shared learner accepts no oracle metadata or future observations."""

import time
from collections import deque
from dataclasses import dataclass

import numpy as np
from sklearn.linear_model import Ridge

from .diagnostics import CUSUM, ks_test
from .methods import (
    exponentially_weighted_conformal_quantile,
)
from .methods import (
    weighted_conformal_quantile as quantile,
)


def decision_losses(y, pred):
    return 5 * ((y >= 0) & (pred < 0)) + 1 * ((y < 0) & (pred >= 0))


@dataclass(frozen=True)
class LearnerSettings:
    """Operational parameters only: no true changepoint or regime information."""

    window: int
    alpha: float
    threshold: float
    period: int
    budget: int

    @classmethod
    def from_config(cls, config):
        return cls(config.window, config.alpha, config.threshold, config.period, config.budget)


class Learner:
    def __init__(
        self,
        X,
        y,
        cal_X,
        cal_y,
        config,
        method,
        radius_method=None,
        cal_score_times=None,
        radius_half_life=None,
        resource_budget=None,
        action_resource_costs=None,
        validation_X=None,
        validation_y=None,
    ):
        self.config, self.method = LearnerSettings.from_config(config), method
        self.radius_method = radius_method or ("rolling" if method == "rolling" else "fixed")
        if self.radius_method not in {"fixed", "rolling", "exponential"}:
            raise ValueError("radius_method must be 'fixed', 'rolling', or 'exponential'")
        self.radius_half_life = float(
            config.window if radius_half_life is None else radius_half_life
        )
        if not np.isfinite(self.radius_half_life) or self.radius_half_life <= 0:
            raise ValueError("radius_half_life must be finite and positive")
        self.resource_budget = float("inf") if resource_budget is None else float(resource_budget)
        if not np.isfinite(self.resource_budget) and self.resource_budget != float("inf"):
            raise ValueError("resource_budget must be finite and nonnegative")
        if self.resource_budget < 0:
            raise ValueError("resource_budget must be finite and nonnegative")
        self.action_resource_costs = action_resource_costs or {
            "residual_bias_recalibration": 1.0,
            "normalized_sgd_partial_update": 2.0,
            "refit": 4.0,
        }
        if any(
            not np.isfinite(value) or value < 0 for value in self.action_resource_costs.values()
        ):
            raise ValueError("action resource costs must be finite and nonnegative")
        self.resource_spent = 0.0
        self.training_seconds = self.inference_seconds = 0.0
        self._fit(X, y)
        pred = self.model.predict(cal_X)
        residual = cal_y - pred
        self.scores = deque(abs(residual), maxlen=config.window)
        if cal_score_times is None:
            if self.radius_method == "exponential":
                raise ValueError("cal_score_times are required for an exponential radius")
            initial_score_times = np.zeros(len(residual), dtype=float)
        else:
            initial_score_times = np.asarray(cal_score_times, dtype=float)
            if (
                initial_score_times.shape != residual.shape
                or not np.isfinite(initial_score_times).all()
            ):
                raise ValueError("cal_score_times must be finite and match calibration rows")
        self.score_times = deque(initial_score_times, maxlen=config.window)
        self.fixed_radius = quantile(abs(residual), config.alpha)
        self.bias_correction = 0.0
        self.feedback_residuals = deque(maxlen=config.window)
        self.reference = cal_X[-config.window :].copy()
        self.features = deque(maxlen=config.window)
        self.history = deque(zip(X.tolist(), y.tolist()), maxlen=config.window)
        self.validation_loss_threshold = None
        self.validation_loss_window = deque(maxlen=config.window)
        if method == "validation_triggered":
            if validation_X is None or validation_y is None:
                raise ValueError(
                    "validation_X and validation_y are required for validation_triggered"
                )
            validation_X = np.asarray(validation_X, dtype=float)
            validation_y = np.asarray(validation_y, dtype=float)
            if (
                validation_X.ndim != 2
                or validation_y.ndim != 1
                or validation_X.shape[0] != validation_y.size
                or validation_X.shape[1] != np.asarray(X).shape[1]
                or validation_y.size < 2
                or not np.isfinite(validation_X).all()
                or not np.isfinite(validation_y).all()
            ):
                raise ValueError("Validation arrays must be finite and have compatible shapes")
            validation_residuals = validation_y - self.model.predict(validation_X)
            validation_losses = validation_residuals**2
            self.validation_loss_threshold = float(
                validation_losses.mean() + 2.0 * validation_losses.std(ddof=1)
            )
        costs = decision_losses(cal_y, pred)
        self.loss_detector = CUSUM(np.mean(costs), np.std(costs), config.threshold)
        self.error_detector = CUSUM(np.mean(residual**2), np.std(residual**2), config.threshold)
        self.alarms = {"ks": [], "loss_cusum": [], "error_cusum": []}
        self.interventions = []
        self.intervention_audit = []
        self.feedback_count = self.cooldown = 0

    def _fit(self, X, y):
        start = time.perf_counter()
        self.model = Ridge(alpha=1.0).fit(X, y)
        self.training_seconds += time.perf_counter() - start

    def predict(self, observation):
        start = time.perf_counter()
        x = np.asarray(observation.features)
        self.features.append(x)
        if (
            len(self.features) == self.config.window
            and observation.time % self.config.window == 0
            and ks_test(self.reference, np.asarray(self.features)) < 0.01
        ):
            self.alarms["ks"].append(observation.time)
        pred = float(self.model.predict(x[None, :])[0]) + self.bias_correction
        if self.radius_method == "rolling":
            radius = quantile(self.scores, self.config.alpha)
        elif self.radius_method == "exponential":
            score_times = np.asarray(self.score_times, dtype=float)
            prior = score_times < observation.time
            radius = exponentially_weighted_conformal_quantile(
                np.asarray(self.scores, dtype=float)[prior],
                observation.time - score_times[prior],
                self.config.alpha,
                self.radius_half_life,
            )
        else:
            radius = self.fixed_radius
        self.inference_seconds += time.perf_counter() - start
        return pred, radius

    def observe(self, feedback):
        self.feedback_count += 1
        signed_residual = float(feedback.target - feedback.prediction)
        self.feedback_residuals.append(signed_residual)
        self.scores.append(abs(feedback.target - feedback.prediction))
        self.score_times.append(feedback.available_at)
        self.history.append((feedback.features, feedback.target))
        loss = float(
            decision_losses(np.array([feedback.target]), np.array([feedback.prediction]))[0]
        )
        if self.loss_detector.update(loss):
            self.alarms["loss_cusum"].append(feedback.available_at)
        alarm = self.error_detector.update((feedback.target - feedback.prediction) ** 2)
        observed_squared_error = float((feedback.target - feedback.prediction) ** 2)
        self.validation_loss_window.append(observed_squared_error)
        validation_alarm = bool(
            self.method == "validation_triggered"
            and self.validation_loss_threshold is not None
            and len(self.validation_loss_window) == self.config.window
            and np.mean(self.validation_loss_window) > self.validation_loss_threshold
        )
        if alarm:
            self.alarms["error_cusum"].append(feedback.available_at)
        if validation_alarm:
            self.alarms.setdefault("validation_loss", []).append(feedback.available_at)
        self.cooldown = max(0, self.cooldown - 1)
        periodic = self.method in {"periodic", "periodic_recalibration"} and (
            self.feedback_count % self.config.period == 0
        )
        triggered = (
            self.method in {"triggered", "recalibration", "partial_update"}
            and alarm
            and self.cooldown == 0
        ) or (self.method == "validation_triggered" and validation_alarm and self.cooldown == 0)
        if (periodic or triggered) and len(self.interventions) < self.config.budget:
            action = (
                "residual_bias_recalibration"
                if self.method in {"recalibration", "periodic_recalibration"}
                else "normalized_sgd_partial_update"
                if self.method == "partial_update"
                else "refit"
            )
            resource_cost = float(self.action_resource_costs[action])
            if self.resource_spent + resource_cost > self.resource_budget:
                return
            action_started = time.perf_counter()
            if self.method in {"recalibration", "periodic_recalibration"}:
                self.bias_correction += float(np.mean(self.feedback_residuals))
            elif self.method == "partial_update":
                features = np.asarray(feedback.features, dtype=float)
                step = 0.1 / (1.0 + float(features @ features))
                residual = float(feedback.target - feedback.prediction)
                self.model.coef_ = self.model.coef_ + step * residual * features
                self.model.intercept_ = self.model.intercept_ + step * residual
            else:
                X, y = zip(*self.history)
                self._fit(np.asarray(X), np.asarray(y))
            self.interventions.append(feedback.available_at)
            self.resource_spent += resource_cost
            self.intervention_audit.append(
                {
                    "available_at": feedback.available_at,
                    "arrived_feedback_count": self.feedback_count,
                    "method": self.method,
                    "action": action,
                    "resource_cost": resource_cost,
                    "resource_spent": self.resource_spent,
                    "elapsed_seconds": time.perf_counter() - action_started,
                    "bias_correction": self.bias_correction,
                }
            )
            self.cooldown = self.config.window
