"""Validated benchmark configuration."""
